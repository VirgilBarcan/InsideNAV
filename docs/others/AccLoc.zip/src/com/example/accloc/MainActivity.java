package com.example.accloc;

import android.support.v7.app.ActionBarActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

// Check line 102 for Accelerometer values
// Check line 156 for Compass Correction value

public class MainActivity extends ActionBarActivity implements SensorEventListener{
	
	Sensor accelerometer;
	SensorManager sm;
	TextView acceleration;
	TextView orientation;
	
	Sensor compass;
	
	static int x=5, y=3, temp_orientation=0;
	
	Button reset;

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		sm = (SensorManager)getSystemService(SENSOR_SERVICE);
		
		accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		sm.registerListener(this, accelerometer, 100);
		acceleration = (TextView)findViewById(R.id.acceleration);
		
		compass = sm.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		sm.registerListener(this, compass, SensorManager.SENSOR_DELAY_NORMAL);
		orientation = (TextView)findViewById(R.id.orientation);
		
		reset();
		
//		ImageView imageView=(ImageView) findViewById(R.id.imageView2);
//        Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);    
//        Canvas canvas = new Canvas(bitmap);
//        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
//        paint.setColor(Color.BLACK);
//        canvas.drawCircle(15, 15, 10, paint);
//        imageView.setImageBitmap(bitmap);
	}

	public void reset() {
		reset = (Button) findViewById(R.id.reset);
		reset.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				x=5;
				y=3;
				ImageView imageViewBuilding = (ImageView) findViewById(R.id.location);
        		String loc = "location" + x + y;
        		int id = getResources().getIdentifier(loc, "drawable", getPackageName());
        		imageViewBuilding.setImageResource(id);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onSensorChanged(SensorEvent event) {	
		Sensor sensor = event.sensor;
        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
        	acceleration.setText("X: \t" + event.values[0] + "\n"
					   + "Y: \t" + event.values[1] + "\n"
					   + "Z: \t" + event.values[2]);
        	if(event.values[2]>10) {
        		ImageView imageViewBuilding = (ImageView) findViewById(R.id.location);
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
//        		if(temp_orientation>337.5 || temp_orientation<=22.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("N " + s);
//        			// N
//        			if(x>1)x--;
//        		}
//        		
//        		if(temp_orientation>22.5  && temp_orientation<=67.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("NE " + s);
//        			// NE
//        			if(x>1)x--;
//        			if(y<5)y++;
//        		}
//        		
//        		if(temp_orientation>67.5  && temp_orientation<=112.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("E " + s);
//        			// E
//        			if(y<5)y++;
//        		}
//        		
//        		if(temp_orientation>112.5  && temp_orientation<=157.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("SE " + s);
//        			// SE
//        			if(x<5)x++;
//        			if(y<5)y++;
//        		}
//        		
//        		if(temp_orientation>157.5  && temp_orientation<=202.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("S " + s);
//        			// S
//        			if(x<5)x++;
//        		}
//        		
//        		if(temp_orientation>202.5  && temp_orientation<=247.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("SW " + s);
//        			// SW
//        			if(x<5)x++;
//        			if(y>1)y--;
//        		}
//        		
//        		if(temp_orientation>247.5  && temp_orientation<=292.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("W " + s);
//        			// W
//        			if(x>1)y--;
//        		}
//        		
//        		if(temp_orientation>292.5  && temp_orientation<=337.5){
//        			String s = Integer.toString(temp_orientation);
//                	orientation.setText("NW " + s);
//        			// NW
//        			if(x>1)x--;
//        			if(y>1)y--;
//        		}
        		
        		if(temp_orientation>300 || temp_orientation<=60){
        			String s = Integer.toString(temp_orientation);
                	orientation.setText("N " + s);
        			// N
        			if(x>1)x--;
        		}
        		
        		if(temp_orientation>60  && temp_orientation<=180){
        			String s = Integer.toString(temp_orientation);
                	orientation.setText("E " + s);
        			// E
                	if(y<5)y++;
        		}
        		
        		if(temp_orientation>180  && temp_orientation<=300){
        			String s = Integer.toString(temp_orientation);
                	orientation.setText("W " + s);
        			// W
                	if(y>1)y--;
        		}
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		String loc = "location" + x + y;
        		Log.d("ACTION", "x=" + x + " y=" + y);
        		int id = getResources().getIdentifier(loc, "drawable", getPackageName());
        		imageViewBuilding.setImageResource(id);
        	}
        }else if (sensor.getType() == Sensor.TYPE_ORIENTATION) {
        	int degree = Math.round(event.values[0]);
        	temp_orientation = degree;
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
//        	if(temp_orientation>337.5 || temp_orientation<=22.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("N " + s);
//    			// N
//    		}
//    		
//    		if(temp_orientation>22.5  && temp_orientation<=67.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("NE " + s);
//    			// NE
//    		}
//    		
//    		if(temp_orientation>67.5  && temp_orientation<=112.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("E " + s);
//    			// E
//    		}
//    		
//    		if(temp_orientation>112.5  && temp_orientation<=157.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("SE " + s);
//    			// SE
//    		}
//    		
//    		if(temp_orientation>157.5  && temp_orientation<=202.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("S " + s);
//    			// S
//    		}
//    		
//    		if(temp_orientation>202.5  && temp_orientation<=247.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("SW " + s);
//    			// SW
//    		}
//    		
//    		if(temp_orientation>247.5  && temp_orientation<=292.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("W " + s);
//    			// W
//    		}
//    		
//    		if(temp_orientation>292.5  && temp_orientation<=337.5){
//    			String s = Integer.toString(temp_orientation);
//            	orientation.setText("NW " + s);
//    			// NW
//    		}

        	if(temp_orientation>300 || temp_orientation<=60){
    			String s = Integer.toString(temp_orientation);
            	orientation.setText("N " + s);
    			// N
    		}
    		
    		if(temp_orientation>60  && temp_orientation<=180){
    			String s = Integer.toString(temp_orientation);
            	orientation.setText("E " + s);
    			// E
    		}
    		
    		if(temp_orientation>180  && temp_orientation<=300){
    			String s = Integer.toString(temp_orientation);
            	orientation.setText("W " + s);
    			// W
    		}
    		
    		
    		
    		
    		
    		
    		
    		
        }
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}
}
