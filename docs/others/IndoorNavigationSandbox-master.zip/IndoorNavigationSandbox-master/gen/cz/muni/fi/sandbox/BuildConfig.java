/** Automatically generated file. DO NOT MODIFY */
package cz.muni.fi.sandbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}