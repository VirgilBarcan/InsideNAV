function heading = dcm2heading(dcm)
heading=atan2(dcm(2,1), dcm(1,1));