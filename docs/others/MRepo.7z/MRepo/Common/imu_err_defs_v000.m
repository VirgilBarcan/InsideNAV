%In a C implementation, these parameters would be in a header file. Matlab
%does not have a preprocessor. Therefore, I use such a dummy function to define
%error model parameters.

%Note that the return values of this function is not standard at all.
%Whenever, you want to use a new model, just use a new imutype and define
%whatever you want.
%Don't delete the existing ones as there may be some example scripts using
%the existing values.

function IMU_ERRDEF=imu_err_defs(imutype)

switch (imutype)
    case 1  %Error model used in OPP
        %Accel
        IMU_ERRDEF.acc_bias_Tc=3600;       %sec
        IMU_ERRDEF.acc_bias_Q=5e-9;        %(m/s^2)^2
        IMU_ERRDEF.acc_bias_var=(3e-3)^2;  %(m/s^2)^2 : SS value=(Tc*Q/2)

        IMU_ERRDEF.acc_scale_Q=1.38e-6;    %ppt^2
        IMU_ERRDEF.acc_scale_var=0.1^2;    %ppt^2 (initial var of rw)

        IMU_ERRDEF.acc_vrw=0.00066^2;      %(m/s/sqrt(s))^2

        %Gyro
        IMU_ERRDEF.gyro_bias_Tc=3600;      %sec
        IMU_ERRDEF.gyro_bias_Q=1.3e-14;    %(rad/sec)^2
        IMU_ERRDEF.gyro_bias_var=(4.83e-6)^2;  %(rad/sec)^2 : SS value=(Tc*Q/2)

        IMU_ERRDEF.gyro_scale_Q=1.38e-6;    %ppt^2
        IMU_ERRDEF.gyro_scale_var=0.1^2;    %ppt^3 (initial var of rw)

        IMU_ERRDEF.gyro_arw=(3.63e-5)^2;   %(rad/sqrt(s))^2
    case 2 %Error model for SiIMU02 (see http://www.atlanticinertial.com/uploads/pdfs/4232-SiIMU02low.pdf)
        %Accel
        IMU_ERRDEF.acc_bias_Tc=1800;       %sec
        IMU_ERRDEF.acc_bias_Q=(0.5*10*1e-3)^2*(2/IMU_ERRDEF.acc_bias_Tc);     %0.5mg SS --> (m/s^2)^2 (compute this based on SS. value and made-up time constant)
        IMU_ERRDEF.acc_bias_var=(10*10*1e-3)^2;  %10mg --> (m/s^2)^2 (repeatability)

        IMU_ERRDEF.acc_scale_var=1.5^2;    %1500ppm --> ppt^2
        IMU_ERRDEF.acc_scale_Q=1e-6;    %ppt^2

        IMU_ERRDEF.acc_vrw=(0.5/60)^2;      %0.5m/s/sqrt(hr) --> (m/s/sqrt(s))^2

        %Gyro
        IMU_ERRDEF.gyro_bias_Tc=1800;      %sec
        IMU_ERRDEF.gyro_bias_Q=(4*pi/180/3600)^2*(2/IMU_ERRDEF.gyro_bias_Tc);    %1.5d/hr - 6.5d/hr SS --> (rad/sec)^2 (compute this based on SS. value and made-up time constant)
        IMU_ERRDEF.gyro_bias_var=(75*pi/180/3600)^2;  %50d/hr - 100d/hr --> (rad/sec)^2

        IMU_ERRDEF.gyro_scale_var=0.5^2;    %500ppm --> ppt^2 
        IMU_ERRDEF.gyro_scale_Q=1e-6;    %ppt^2

        IMU_ERRDEF.gyro_arw=(0.3*pi/180/60)^2; %0.1d/sqr(hr) - 0.5d/sqrt(hr) --> (rad/sqrt(s))^2 
    case 3 %Error model for LN200
        %%Accel
        IMU_ERRDEF.acc_bias_Tc=20*60;       %sec
        IMU_ERRDEF.acc_bias_Q=(0.05*10*1e-3)^2*(2/IMU_ERRDEF.acc_bias_Tc);     %50ug (SS) --> (m/s^2)^2 
        IMU_ERRDEF.acc_bias_var=(0.6*10*1e-3)^2;  %300ug - 1mg --> (m/s^2)^2

        IMU_ERRDEF.acc_scale_var=0.6^2;    %300ppm - 5000ppm --> ppt^2
        IMU_ERRDEF.acc_scale_Q=1e-6;    %ppt^2

        IMU_ERRDEF.acc_vrw=(50*10*1e-6)^2;      %50ug/sqrt(hz) --> (m/s/sqrt(s))^2

        %%Gyro
        IMU_ERRDEF.gyro_bias_Tc=20*60;      %sec
        IMU_ERRDEF.gyro_bias_Q=(0.35*pi/180/3600)^2*(2/IMU_ERRDEF.gyro_bias_Tc);    %0.35d/hr SS --> (rad/sec)^2
        IMU_ERRDEF.gyro_bias_var=(2*pi/180/3600)^2;  %1d/hr - 3d/hr --> (rad/sec)^2

        IMU_ERRDEF.gyro_scale_var=0.3^2;    %100ppm-500ppm --> ppt^2 
        IMU_ERRDEF.gyro_scale_Q=1e-6;    %ppt^2

        IMU_ERRDEF.gyro_arw=(0.1*pi/180/60)^2; %0.07d/sqr(hr) - 0.15d/sqrt(hr) --> (rad/sqrt(s))^2
    case 4  % LN200 error model in continious time state space form without SF errors(see the "case 3" for
            % the definition of the numerical values)
                %x_dot=A*x+Bw (imu error states)
                %y=u+(Cti+u*Ctv)*x+Dv  (sensor output. Dv is the A/VRW. u is the true acc/rotation rate)
                %E{|Bw|^2}=Q;, E{|Dv|^2}=R, E{|x0|^2}=P0
         IMU_ERRDEF.Acc.A=-1/(20*60);   %bias
         IMU_ERRDEF.Acc.Q=(0.05*10*1e-3)^2*(2/1200);
         IMU_ERRDEF.Acc.P0=(0.6*10*1e-3)^2;
         IMU_ERRDEF.Acc.Cti=1;
         %IMU_ERRDEF.Acc.Ctv=[];     %ppt not ppm
         IMU_ERRDEF.Acc.R=(50*10*1e-6)^2;   %vrw
         
         IMU_ERRDEF.Gyro.A=-1/(20*60);   %bias, scale factor
         IMU_ERRDEF.Gyro.Q=(0.35*pi/180/3600)^2*(2/1200);
         IMU_ERRDEF.Gyro.P0=(2*pi/180/3600)^2;
         IMU_ERRDEF.Gyro.Cti=1;
         %IMU_ERRDEF.Gyro.Ctv=[];     %ppt not ppm
         IMU_ERRDEF.Gyro.R=(0.1*pi/180/60)^2;   %arw
end
