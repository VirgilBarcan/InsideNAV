%% Sensor error definitions for 100Hz
sen_errdef(1).A=[1];
sen_errdef(1).B=[0.55e-4];
sen_errdef(1).C=[1];
sen_errdef(1).D=[sqrt(3.0e-6)/0.1];
sen_errdef(1).sP=[1e-2];
sen_errdef(1).tparam=[];  %first param=sP of temperature scale factor (RC), second=B of temperature RW

sen_errdef(2)=sen_errdef(1);
sen_errdef(6)=sen_errdef(1);

sen_errdef(3).A=[0.999986611151365];
sen_errdef(3).B=[1.3e-6];
sen_errdef(3).C=[1];
sen_errdef(3).D=[sqrt(1e-006)/0.1];
sen_errdef(3).sP=[5e-4];
sen_errdef(3).tparam=[];

sen_errdef(5).A=[1];
sen_errdef(5).B=[9e-5];
sen_errdef(5).C=[1];
sen_errdef(5).D=[0.005];
sen_errdef(5).sP=[sqrt(6e-009)];
sen_errdef(5).tparam=[];

sen_errdef(4).A=[1];
sen_errdef(4).B=[1e-5];
sen_errdef(4).C=[1];
sen_errdef(4).D=[0.005];
sen_errdef(4).sP=[sqrt(6e-008)];
sen_errdef(4).tparam=[];

%%observation err defs
obs_errdef(1).sR=eye(3)*1;
obs_errdef(2).sR=eye(3)*0.1;

%%initial err defs
ini_errdef.pos_sP=[0.1 0 0;0 0.1 0;0 0 0];
ini_errdef.vel_sP=[0.1 0 0;0 0.1 0;0 0 0];
ini_errdef.att_sP=[0 0 0;0 0 0;0 0 0.2*pi/180];

%temparature model
tem_mod.A=1;
tem_mod.B=0;
tem_mod.u=0.001;